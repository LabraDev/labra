package services

/*
import "net/http"

func Login(w http.ResponseWriter, r *http.Request) {
	r.Cookie()
}*/
